/**
 * Descripción:
 * Programa para procesar registros de una bitácora, permitiendo ordenarlos 
 * por fecha y filtrar registros dentro de un rango de tiempo especificado 
 * por el usuario. El programa incluye funcionalidades para:
 * - Leer un archivo de texto con registros y fechas en formato "MMM DD HH/MM/SS".
 * - Convertir las fechas a un formato manejable (`time_t`).
 * - Ordenar los registros mediante el algoritmo Merge Sort.
 * - Filtrar registros dentro de un rango de fechas definido por el usuario.
 * - Guardar los registros ordenados en un archivo.
 * - Guardar los registros filtrados en un archivo separado.
 * 
 * Autor: Equipo 3
 * 
 * Fecha: 19/01/25
 */



#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <ctime>
#include <iomanip>

using namespace std;

// Convierte una cadena de fecha en formato "MMM DD HH:MM:SS" a `time_t`
time_t parseDate(const string&);

// Ajusta `time_t` a las 00:00:00 o 23:59:59 del día correspondiente
time_t ajustarHora(time_t, bool);

// Función para mezclar subarreglos (Merge Sort)
void mezclarSubArreglos(vector<pair<time_t, string>>&, int, int, int);

// Ordena los registros por fecha (Merge Sort)
void ordenamientoMerge(vector<pair<time_t, string>>&, int, int);

// Búsqueda binaria para encontrar el índice del inicio del rango
int buscarInicio(const vector<pair<time_t, string>>&, time_t);

// Búsqueda binaria para encontrar el índice del final del rango
int buscarFin(const vector<pair<time_t, string>>&, time_t);

/**
 * Descripción:
 *  
 * Parámetros:
 *  
 * Retorno:
 *  
 * Complejidad:
 *  
 */
// Función para guardar los registros en un archivo
void guardarRegistrosEnArchivo(const string& nombreArchivo, const vector<pair<time_t, string>>& registros, int inicio = 0, int fin = -1) {
    ofstream archivoSalida(nombreArchivo);
    if (!archivoSalida.is_open()) {
        cerr << "Error: No se pudo abrir el archivo de salida." << endl;
        return;
    }

    if (fin == -1) fin = registros.size() - 1; // Guardar todos los registros si no se especifica el rango

    if (inicio == -1 || fin == -1 || inicio > fin) {
        archivoSalida << "No se encontraron registros en el rango especificado." << endl;
        cout << "No se encontraron registros en el rango especificado. Ver '" << nombreArchivo << "'." << endl;
    } else {
        for (int i = inicio; i <= fin; ++i) {
            archivoSalida << registros[i].second << endl; // Guardar la línea completa
        }
        cout << "Registros guardados en '" << nombreArchivo << "'." << endl;
    }
    archivoSalida.close();
}

int main() {
    string nombreArchivo = "bitacora.txt";
    vector<pair<time_t, string>> registros;

    // Leer el archivo original y extraer las fechas
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cerr << "Error: No se pudo abrir el archivo." << endl;
        return 1;
    }

    string linea;
    while (getline(archivo, linea)) {
        if (linea.size() < 15) continue; // Ignorar líneas inválidas
        string fechaStr = linea.substr(0, 15); // Extraer los primeros 15 caracteres como fecha
        time_t fecha = parseDate(fechaStr);   // Convertir la fecha a `time_t`
        if (fecha != -1) {
            registros.emplace_back(fecha, linea); // Almacenar la fecha y la línea completa
        }
    }
    archivo.close();

    // Ordenar los registros por fecha y guardar todos en `bitacora_ordenada.txt`
    ordenamientoMerge(registros, 0, registros.size() - 1);
    guardarRegistrosEnArchivo("bitacora_ordenada.txt", registros);

    // Solicitar rango al usuario
    cout << "¿Desea ingresar horas manualmente o usar el rango completo del día? (m: manual, c: completo): ";
    char opcion;
    cin >> opcion;
    cin.ignore(); // Consumir el salto de línea

    time_t fechaInicio, fechaFin;
    if (opcion == 'c' || opcion == 'C') {
        cout << "Ingrese la fecha de inicio (formato: MMM DD): ";
        string fechaInicioBaseStr;
        getline(cin, fechaInicioBaseStr);
        cout << "Ingrese la fecha de fin (formato: MMM DD): ";
        string fechaFinBaseStr;
        getline(cin, fechaFinBaseStr);

        fechaInicio = parseDate(fechaInicioBaseStr + " 00:00:00");
        fechaFin = parseDate(fechaFinBaseStr + " 23:59:59");

        if (fechaInicio == -1 || fechaFin == -1) {
            cerr << "Error: Fechas base inválidas." << endl;
            return 1;
        }
    } else {
        // Solicitar fechas al usuario
        cout << "Ingrese la fecha de inicio (formato: MMM DD HH:MM:SS): ";
        string fechaInicioStr;
        getline(cin, fechaInicioStr);
        fechaInicio = parseDate(fechaInicioStr);

        cout << "Ingrese la fecha de fin (formato: MMM DD HH:MM:SS): ";
        string fechaFinStr;
        getline(cin, fechaFinStr);
        fechaFin = parseDate(fechaFinStr);

        if (fechaInicio == -1 || fechaFin == -1) {
            cerr << "Error: Fechas ingresadas inválidas." << endl;
            return 1;
        }
    }

    // Buscar el rango de registros y guardarlos en `bitacora_filtrada.txt`
    int inicio = buscarInicio(registros, fechaInicio);
    int fin = buscarFin(registros, fechaFin);
    guardarRegistrosEnArchivo("bitacora_filtrada.txt", registros, inicio, fin);

    return 0;
}

/**
 * Descripción:
 * Convierte una cadena de texto que representa una fecha en formato "MMM DD HH:MM:SS"
 * a un valor de tiempo (`time_t`) que se puede utilizar para cálculos.
 * 
 * Parámetros:
 * - dateString: Cadena de texto con la fecha en formato "MMM DD HH:MM:SS".
 * 
 * Retorno:
 * - Un valor `time_t` que representa la fecha y hora convertida.
 * - Devuelve -1 si la conversión falla.
 * 
 * Complejidad:
 * - O(1), ya que la conversión utiliza operaciones de extracción y manipulación constantes.
 */
time_t parseDate(const string& dateString) {
    tm tm = {};
    istringstream ss(dateString);
    ss >> get_time(&tm, "%b %d %H:%M:%S");
    if (ss.fail()) {
        cerr << "Error: No se pudo convertir la fecha '" << dateString << "'" << endl;
        return -1;
    }
    return mktime(&tm);
}

/**
 * Descripción:
 * Ajusta un valor de tiempo (`time_t`) al inicio o al final del día.
 * 
 * Parámetros:
 * - fecha: Valor `time_t` que representa una fecha y hora.
 * - inicioDelDia: Booleano que indica si se debe ajustar al inicio del día (00:00:00)
 *   o al final del día (23:59:59).
 * 
 * Retorno:
 * - El valor `time_t` ajustado al inicio o al final del día correspondiente.
 * 
 * Complejidad:
 * - O(1), ya que ajusta directamente los campos de tiempo.
 */
time_t ajustarHora(time_t fecha, bool inicioDelDia) {
    tm* tmPtr = localtime(&fecha);
    if (inicioDelDia) {
        tmPtr->tm_hour = 0;
        tmPtr->tm_min = 0;
        tmPtr->tm_sec = 0;
    } else {
        tmPtr->tm_hour = 23;
        tmPtr->tm_min = 59;
        tmPtr->tm_sec = 59;
    }
    return mktime(tmPtr);
}

/**
 * Descripción:
 * Combina dos subarreglos ordenados en un único subarreglo ordenado.
 * Este es un paso fundamental del algoritmo Merge Sort.
 * 
 * Parámetros:
 * - registros: Vector de pares (time_t, string) que contiene los registros.
 * - inicio: Índice del inicio del primer subarreglo.
 * - mitad: Índice del final del primer subarreglo.
 * - fin: Índice del final del segundo subarreglo.
 * 
 * Retorno:
 * - Ninguno. El vector `registros` se modifica en su lugar.
 * 
 * Complejidad:
 * - O(n), donde n es el número de elementos entre `inicio` y `fin`.
 */
void mezclarSubArreglos(vector<pair<time_t, string>>& registros, int inicio, int mitad, int fin) {
    int nIzq = mitad - inicio + 1;
    int nDer = fin - mitad;

    vector<pair<time_t, string>> izquierda(registros.begin() + inicio, registros.begin() + inicio + nIzq);
    vector<pair<time_t, string>> derecha(registros.begin() + mitad + 1, registros.begin() + mitad + 1 + nDer);

    int i = 0, j = 0, k = inicio;
    while (i < nIzq && j < nDer) {
        if (izquierda[i].first <= derecha[j].first) {
            registros[k++] = izquierda[i++];
        } else {
            registros[k++] = derecha[j++];
        }
    }

    while (i < nIzq) registros[k++] = izquierda[i++];
    while (j < nDer) registros[k++] = derecha[j++];
}

/**
 * Descripción:
 * Implementa el algoritmo de ordenamiento Merge Sort para ordenar los registros por fecha.
 * 
 * Parámetros:
 * - registros: Vector de pares (time_t, string) que contiene los registros a ordenar.
 * - inicio: Índice del primer elemento del subarreglo.
 * - fin: Índice del último elemento del subarreglo.
 * 
 * Retorno:
 * - Ninguno. El vector `registros` se modifica en su lugar.
 * 
 * Complejidad:
 * - O(n log n), donde n es el número de elementos en el vector.
 */
void ordenamientoMerge(vector<pair<time_t, string>>& registros, int inicio, int fin) {
    if (inicio < fin) {
        int mitad = (inicio + fin) / 2;
        ordenamientoMerge(registros, inicio, mitad);
        ordenamientoMerge(registros, mitad + 1, fin);
        mezclarSubArreglos(registros, inicio, mitad, fin);
    }
}

/**
 * Descripción:
 * Realiza una búsqueda binaria para encontrar el índice del primer registro
 * cuya fecha sea mayor o igual a la fecha de inicio especificada.
 * 
 * Parámetros:
 * - registros: Vector de pares (time_t, string) ordenado por fecha.
 * - fechaInicio: Valor `time_t` que representa la fecha de inicio del rango.
 * 
 * Retorno:
 * - Índice del primer registro dentro del rango o -1 si no hay coincidencias.
 * 
 * Complejidad:
 * - O(log n), donde n es el número de elementos en el vector.
 */
int buscarInicio(const vector<pair<time_t, string>>& registros, time_t fechaInicio) {
    int bajo = 0, alto = registros.size() - 1, resultado = -1;
    while (bajo <= alto) {
        int central = (bajo + alto) / 2;
        if (registros[central].first >= fechaInicio) {
            resultado = central;
            alto = central - 1; // Busca hacia la izquierda
        } else {
            bajo = central + 1; // Busca hacia la derecha
        }
    }
    return resultado;
}

/**
 * Descripción:
 * Realiza una búsqueda binaria para encontrar el índice del último registro
 * cuya fecha sea menor o igual a la fecha de fin especificada.
 * 
 * Parámetros:
 * - registros: Vector de pares (time_t, string) ordenado por fecha.
 * - fechaFin: Valor `time_t` que representa la fecha de fin del rango.
 * 
 * Retorno:
 * - Índice del último registro dentro del rango o -1 si no hay coincidencias.
 * 
 * Complejidad:
 * - O(log n), donde n es el número de elementos en el vector.
 */
int buscarFin(const vector<pair<time_t, string>>& registros, time_t fechaFin) {
    int bajo = 0, alto = registros.size() - 1, resultado = -1;
    while (bajo <= alto) {
        int central = (bajo + alto) / 2;
        if (registros[central].first <= fechaFin) {
            resultado = central;
            bajo = central + 1; // Busca hacia la derecha
        } else {
            alto = central - 1; // Busca hacia la izquierda
        }
    }
    return resultado;
}
