/*Descripcion
El programa lee un archivo "bitacora.txt" estrae las direcciones IP
de cada linea utilizando expresiones regulares. Cuenta cuantas veces aparace
cada IP en el archivo. ordena la cantidad de accesos.

Equipo 4*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <vector>
#include <regex>

using namespace std;

// Función para extraer la IP de una línea de la bitácora
string extraerIP(const string& linea) {
    regex ipRegex(R"((\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}))");
    smatch match;
    if (regex_search(linea, match, ipRegex)) {
        return match.str(0);
    }
    return "";
}

int main() {
    string nombreArchivo = "bitacora.txt";
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cerr << "Error: No se pudo abrir el archivo." << endl;
        return 1;
    }

    map<string, int> conteoIPs;  // Mapa para contar accesos por IP
    string linea;

    while (getline(archivo, linea)) {
        string ip = extraerIP(linea);
        if (!ip.empty()) {
            conteoIPs[ip]++;
        }
    }
    archivo.close();

    // Insertar en un multimap ordenado por cantidad de accesos (BST )
    multimap<int, string, greater<int>> bst;
    for (const auto& par : conteoIPs) {
        bst.insert({par.second, par.first});
    }

    // Mostrar las 5 IPs con más accesos
    cout << "Top 5 IPs con más accesos:" << endl;
    int count = 0;
    for (const auto& par : bst) {
        cout << "IP: " << par.second << " - Accesos: " << par.first << endl;
        if (++count == 5) break;
    }

    return 0;
}
