/**
 * Descripción:
 * El Programa procesa un archivo de la bitacora (bitacor.txt) 
 * para ordenar registros por IP y filtrar registros por 
 * un rango de IPs. Entre sus funcionalidades, permite extraer 
 * direcciones IP de los registros, ordenarlas, solicitar al 
 * usuarion un rango de IPs y guardar los registros filtrados. 
 * 
 * Autor: Equipo 4
 * 
 * Fecha: 24/01/25
    */
#include <algorithm>  
#include <regex>      
#include <vector>     
#include <iostream>   
#include <fstream>    
#include <string>     
#include <sstream>    

using namespace std;

// Función para extraer la IP de un registro usando expresiones regulares
string extraerIP(const string& linea) {
    // Expresión regular para capturar direcciones IP en formato numérico
    regex ipRegex(R"((\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}))");
    smatch match;  // Objeto para almacenar el resultado de la búsqueda
    if (regex_search(linea, match, ipRegex)) {
        return match.str(0); // Retorna la primera coincidencia de la IP
    }
    return ""; // Si no encuentra IP, retorna una cadena vacía
}

// Función para ordenar los registros por IP (lexicográficamente)
void ordenarPorIP(vector<pair<string, string>>& registros) {
    // Usa sort con un comparador lambda para ordenar por la clave (IP)
    sort(registros.begin(), registros.end(),
         [](const pair<string, string>& a, const pair<string, string>& b) {
             return a.first < b.first; // Comparar las IPs (lexicográficamente)
         });
}

// Función para guardar los registros en un archivo
void guardarEnArchivo(const string& nombreArchivo, const vector<string>& registros) {
    ofstream archivoSalida(nombreArchivo); // Crear archivo de salida
    if (!archivoSalida.is_open()) { // Verificar si se puede abrir el archivo
        cerr << "Error: No se pudo abrir el archivo de salida." << endl;
        return;
    }
    for (const string& registro : registros) {
        archivoSalida << registro << endl; // Escribir cada registro en el archivo
    }
    archivoSalida.close(); // Cerrar el archivo
    cout << "Registros guardados en '" << nombreArchivo << "'." << endl;
}

int main() {
    string nombreArchivo = "bitacora.txt"; // Nombre del archivo de entrada
    vector<pair<string, string>> registros; // Vector para almacenar (IP, línea completa)

    // Leer el archivo y extraer las IPs
    ifstream archivo(nombreArchivo); // Abrir archivo de entrada
    if (!archivo.is_open()) { // Verificar si el archivo se pudo abrir
        cerr << "Error: No se pudo abrir el archivo." << endl;
        return 1;
    }

    string linea;
    while (getline(archivo, linea)) { // Leer línea por línea
        string ip = extraerIP(linea); // Extraer la IP de la línea
        if (!ip.empty()) { // Si se encontró una IP válida
            registros.emplace_back(ip, linea); // Guardar (IP, línea completa) en el vector
        }
    }
    archivo.close(); // Cierra el archivo de entrada

    // Ordenar los registros por IP
    ordenarPorIP(registros);

    // Guardar registros ordenados en "bitacora_ordenada_por_ip.txt"
    vector<string> registrosOrdenados;
    for (const auto& registro : registros) {
        registrosOrdenados.push_back(registro.second); // Extraer solo las líneas completas
    }
    guardarEnArchivo("bitacora_ordenada_por_ip.txt", registrosOrdenados);

    // Solicitar rango de IPs al usuario
    string ipInicio, ipFin;
    cout << "Ingrese la IP de inicio: ";
    cin >> ipInicio;
    cout << "Ingrese la IP de fin: ";
    cin >> ipFin;

    // Buscar registros dentro del rango de IPs
    vector<string> registrosFiltrados;
    for (const auto& registro : registros) {
        if (registro.first >= ipInicio && registro.first <= ipFin) {
            registrosFiltrados.push_back(registro.second); // Guardar registros en el rango
        }
    }

    // Guardar registros filtrados en "bitacora_filtrada_por_ip.txt"
    guardarEnArchivo("bitacora_filtrada_por_ip.txt", registrosFiltrados);

    return 0;
}
