#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

// Función para extraer la IP de una línea de la bitácora
string extraerIP(const string& linea) {
    istringstream stream(linea);
    string fecha, hora, ip;
    stream >> fecha >> hora >> ip; // Extrae los primeros tres elementos
    return ip.substr(0, ip.find(':')); // Elimina el puerto
}

int main() {
    string nombreArchivo = "bitacora.txt";
    ifstream archivo(nombreArchivo);
    
    if (!archivo.is_open()) {
        cerr << "Error: No se pudo abrir el archivo." << endl;
        return 1;
    }

    map<int, vector<string>> bst; // BST simulando key=accesos, value=lista de IPs
    map<string, int> conteoIPs; // Para contar accesos por IP
    string linea;

    // Leer cada línea del archivo y extraer la IP
    while (getline(archivo, linea)) {
        string ip = extraerIP(linea);
        if (!ip.empty()) {
            conteoIPs[ip]++;
        }
    }
    archivo.close();

    // Insertar datos en BST
    for (const auto& par : conteoIPs) {
        bst[par.second].push_back(par.first);
    }

    // Mostrar todas las IPs con sus accesos
    cout << "Lista de accesos por IP:" << endl;
    for (const auto& par : conteoIPs) {
        cout << "IP: " << par.first << " - Accesos: " << par.second << endl;
    }

    // Obtener las 5 IPs con más accesos
    cout << "\nTop 5 IPs con más accesos:" << endl;
    int count = 0;
    for (auto it = bst.rbegin(); it != bst.rend() && count < 5; ++it) {
        for (const auto& ip : it->second) {
            cout << "IP: " << ip << " - Accesos: " << it->first << endl;
            count++;
            if (count == 5) break;
        }
    }

    return 0;
}