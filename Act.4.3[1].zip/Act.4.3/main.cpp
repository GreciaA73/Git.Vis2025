// Este programa lee un archivo de registro "bitacora.txt" y extrae direcciones IP, tiempos y fechas.
// También determina el fan-out de cada dirección IP (número de ocurrencias).
// La complejidad de las operaciones utilizadas es la siguiente:
// - Lectura de archivo: O(n), donde n es el número de líneas en el archivo.
// - Coincidencia de expresiones regulares: O(m) para cada línea, donde m es la longitud de la línea.
// Complejidad general: O(n * m) en el peor de los casos.

//Equipo 4
//Grecia Estefania Rchuleta Rivera A00840745
//Maria José Ruíz Martínez  A01769398


#include <iostream>
#include <fstream>
#include <regex>
#include <string>
#include <unordered_map> // Para contar ocurrencias

int main() {
    std::ifstream file("bitacora.txt");
    std::string line;
    std::regex logPattern(R"((\w{3}) (\d{1,2}) (\d{2}:\d{2}:\d{2}) (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}))");
    std::smatch matches;
    std::unordered_map<std::string, int> ipCount; // Mapa para contar ocurrencias de cada IP

    if (!file.is_open()) {
        std::cerr << "Error al abrir el archivo." << std::endl;
        return 1;
    }

    while (std::getline(file, line)) {
        if (std::regex_search(line, matches, logPattern)) {
            std::string ip = matches[4]; // Extraer la dirección IP
            ipCount[ip]++; // Incrementar el conteo para esta IP
            std::cout << "Fecha: " << matches[1] << " " << matches[2] << ", Hora: " << matches[3] << ", IP: " << ip << std::endl;
        }
    }

    // Salida del fan-out (ocurrencias) para cada dirección IP
    std::cout << "\nFan-out de cada dirección IP:\n";
    std::string bootMasterIP;
    int maxCount = 0;
    bool sameCount = true;
    int firstCount = -1;

    for (const auto& entry : ipCount) {
        std::cout << "IP: " << entry.first << ", Conteo: " << entry.second << std::endl;

        // Verificar el mayor fan-out
        if (entry.second > maxCount) {
            maxCount = entry.second;
            bootMasterIP = entry.first;
        }

        // Verificar si todos los conteos son iguales
        if (firstCount == -1) {
            firstCount = entry.second;
        } else if (firstCount != entry.second) {
            sameCount = false;
        }
    }

    // Salida de resultados según las condiciones
    if (sameCount) {
        std::cout << "Todos los IPs tienen el mismo número de nodos." << std::endl;
    }

    std::cout << "El IP con el mayor fan-out es: " << bootMasterIP << " con " << maxCount << " nodos." << std::endl;
    std::cout << "Presumiblemente, el boot master se encuentra en la dirección IP: " << bootMasterIP << std::endl;

    file.close();
    return 0;
}
